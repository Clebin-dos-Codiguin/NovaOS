const NODE = {
  TYPE: {
    NUMBER: "NT_NUMBER",
    COMMAND: "NT_COMMAND",
    FILE_WRITE: "NT_FILE_WRITE",
    FILE_READ: "NT_FILE_READ",
    FILE_DELETE: "NT_FILE_DELETE",
  },
};

module.exports = NODE;