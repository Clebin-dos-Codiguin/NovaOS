const TOKEN = {
  TYPE: {
    // Tokens existentes
    LPAREN: "TT_LPAREN",
    RPAREN: "TT_RPAREN",
    NUMBER: "TT_NUMBER",
    PLUS: "TT_PLUS",
    MINUS: "TT_MINUS",
    // Novos tokens
    COMMAND: "TT_COMMAND",        // Representa um comando do sistema
    FILE_WRITE: "TT_FILE_WRITE", // Escreve em arquivos
    FILE_READ: "TT_FILE_READ",   // Lê arquivos
    FILE_DELETE: "TT_FILE_DELETE", // Apaga arquivos
  },

  OPERATOR: {
    LPAREN: "(",
    RPAREN: ")",
    PLUS: "pls",
    MINUS: "mns",
    // Operadores para arquivos e comandos
    COMMAND: "cmd",
    FILE_WRITE: "write",
    FILE_READ: "read",
    FILE_DELETE: "del",
  },
};

module.exports = TOKEN;