const fs = require("fs");
const { execSync } = require("child_process");

function evaluate(tree) {
  if (tree.nodeType === NODE.TYPE.COMMAND) {
    try {
      return execSync(tree.command, { encoding: "utf-8" });
    } catch (err) {
      return `Erro ao executar comando: ${err.message}`;
    }
  } else if (tree.nodeType === NODE.TYPE.FILE_WRITE) {
    try {
      fs.writeFileSync(tree.fileName, tree.content);
      return `Arquivo ${tree.fileName} criado com sucesso.`;
    } catch (err) {
      return `Erro ao escrever no arquivo: ${err.message}`;
    }
  } else if (tree.nodeType === NODE.TYPE.FILE_READ) {
    try {
      return fs.readFileSync(tree.fileName, "utf-8");
    } catch (err) {
      return `Erro ao ler o arquivo: ${err.message}`;
    }
  } else if (tree.nodeType === NODE.TYPE.FILE_DELETE) {
    try {
      fs.unlinkSync(tree.fileName);
      return `Arquivo ${tree.fileName} deletado com sucesso.`;
    } catch (err) {
      return `Erro ao deletar o arquivo: ${err.message}`;
    }
  }

  // Avaliação existente
}

module.exports = evaluate;