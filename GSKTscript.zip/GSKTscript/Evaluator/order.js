const NODE = require("../constants/nodeType");

function orderOfEvaluation(tree) {
  if (tree.nodeType === NODE.TYPE.ASSIGN) {
    return `${tree.varName} = ${orderOfEvaluation(tree.expr)}`;
  }
  if (tree.nodeType === NODE.TYPE.IF) {
    return `if (${orderOfEvaluation(tree.condition)}) { ${orderOfEvaluation(
      tree.trueBranch
    )} } else { ${orderOfEvaluation(tree.falseBranch)} }`;
  }
}

module.exports = orderOfEvaluation;