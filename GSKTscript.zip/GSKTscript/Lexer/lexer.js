class Lexer {
  // Método existente

  generateTokens() {
    while (this.currentChar !== undefined) {
      if (this.currentChar === "c" && this.text.slice(this.index - 1, this.index + 2) === "cmd") {
        this.tokens.push(new Token(TOKEN.TYPE.COMMAND, TOKEN.OPERATOR.COMMAND));
        this.index += 2;
        this.advance();
      } else if (this.currentChar === "w" && this.text.slice(this.index - 1, this.index + 4) === "write") {
        this.tokens.push(new Token(TOKEN.TYPE.FILE_WRITE, TOKEN.OPERATOR.FILE_WRITE));
        this.index += 4;
        this.advance();
      } else if (this.currentChar === "r" && this.text.slice(this.index - 1, this.index + 3) === "read") {
        this.tokens.push(new Token(TOKEN.TYPE.FILE_READ, TOKEN.OPERATOR.FILE_READ));
        this.index += 3;
        this.advance();
      } else if (this.currentChar === "d" && this.text.slice(this.index - 1, this.index + 2) === "del") {
        this.tokens.push(new Token(TOKEN.TYPE.FILE_DELETE, TOKEN.OPERATOR.FILE_DELETE));
        this.index += 2;
        this.advance();
      } else {
        // Tokens existentes
        this.advance();
      }
    }

    return this.tokens;
  }
}