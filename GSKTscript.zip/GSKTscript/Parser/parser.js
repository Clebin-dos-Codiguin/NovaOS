class Parser {
  parse() {
    if (this.currentToken.type === TOKEN.TYPE.COMMAND) {
      this.advance();
      const command = this.expr();
      return { nodeType: NODE.TYPE.COMMAND, command };
    } else if (this.currentToken.type === TOKEN.TYPE.FILE_WRITE) {
      this.advance();
      const fileName = this.expr();
      const content = this.expr();
      return { nodeType: NODE.TYPE.FILE_WRITE, fileName, content };
    } else if (this.currentToken.type === TOKEN.TYPE.FILE_READ) {
      this.advance();
      const fileName = this.expr();
      return { nodeType: NODE.TYPE.FILE_READ, fileName };
    } else if (this.currentToken.type === TOKEN.TYPE.FILE_DELETE) {
      this.advance();
      const fileName = this.expr();
      return { nodeType: NODE.TYPE.FILE_DELETE, fileName };
    }

    return this.expr();
  }
}