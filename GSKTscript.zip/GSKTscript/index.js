const Lexer = require("./Lexer/lexer");
const Parser = require("./Parser/parser");
const Evaluate = require("./Evaluator/evaluate");

const code = `
  var x = 5;
  if x pls 2 mns 1 {
    x = x pls 10;
  } else {
    x = x mns 3;
  }
`;

const lexer = new Lexer(code);
const tokens = lexer.generateTokens();

const parser = new Parser(tokens);
const tree = parser.parse();

console.log("Resultado:", Evaluate(tree));